LUI.UICharacterWindow = LUI.Class( LUI.UIElement )
LUI.UICharacterWindow.build = function ( f1_arg0, f1_arg1 )
	return LUI.UICharacterWindow.new()
end

LUI.UICharacterWindow.init = function ( f2_arg0, f2_arg1 )
	LUI.UIElement.init( f2_arg0, f2_arg1 )
end

LUI.UICharacterWindow.setCharacterHandle = function ( f3_arg0, f3_arg1 )
	
end

LUI.UICharacterWindow.id = "LUICharacterWindow"
