LUI.UIUserEmblem = LUI.Class( LUI.UIElement )
LUI.UIUserEmblem.init = function ( f1_arg0, f1_arg1 )
	LUI.UIUserEmblem.super.init( f1_arg0, f1_arg1 )
	f1_arg0:SetupUserEmblem( f1_arg1 )
end

LUI.UIUserEmblem.id = "LUIUserEmblem"
