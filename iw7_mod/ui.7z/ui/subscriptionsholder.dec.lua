LUI.SubscriptionsHolder = LUI.Class()
LUI.SubscriptionsHolder.allocate = function ()
	return ConstructSubscriptionsHolder()
end

LUI.SubscriptionsHolder.init = function ( f2_arg0 )
	
end

