LUI.UIDotGrid = LUI.Class( LUI.UIElement )
LUI.UIDotGrid.init = function ( f1_arg0 )
	LUI.UIDotGrid.super.init( f1_arg0 )
	f1_arg0:SetupDotGrid()
end

LUI.UIDotGrid.id = "UIDotGrid"
